PANADERÍA LA ESPIGA
=====================

Proyecto escolar en PHP y HTML.

Archivos:
- index.php: página principal con información de los panes y selección de cantidades.
- cuenta.php: recibe las cantidades mediante POST y calcula la cuenta.
- estilos.css: diseño visual de las páginas.

Para ejecutarlo:
1. Coloca la carpeta "panaderia_php" dentro de la carpeta htdocs de XAMPP.
2. Inicia Apache desde XAMPP.
3. Abre en el navegador:
   http://localhost/panaderia_php/

No requiere base de datos.
