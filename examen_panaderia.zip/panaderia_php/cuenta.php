<?php
$precios = [
    "pan_dulce" => 12.00,
    "concha" => 15.00,
    "cuernito" => 18.00,
    "empanada" => 20.00,
    "bolillo" => 8.00
];

$nombres = [
    "pan_dulce" => "Pan dulce",
    "concha" => "Concha",
    "cuernito" => "Cuernito",
    "empanada" => "Empanada",
    "bolillo" => "Bolillo"
];

$total = 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cuenta - Panadería La Espiga</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
<header>
    <h1>Panadería La Espiga</h1>
    <p>Cuenta de compra</p>
</header>

<main class="contenedor cuenta">
    <h2>Tu cuenta</h2>

    <?php
    $hayProductos = false;

    foreach ($precios as $producto => $precio) {
        $cantidad = isset($_POST[$producto]) ? (int)$_POST[$producto] : 0;

        if ($cantidad > 0) {
            $hayProductos = true;
            $subtotal = $cantidad * $precio;
            $total += $subtotal;

            echo "<div class='linea'>";
            echo "<span>{$nombres[$producto]} x {$cantidad}</span>";
            echo "<strong>$" . number_format($subtotal, 2) . "</strong>";
            echo "</div>";
        }
    }

    if (!$hayProductos) {
        echo "<p>No seleccionaste ningún pan.</p>";
    }
    ?>

    <div class="total">
        Total: $<?php echo number_format($total, 2); ?>
    </div>

    <a class="boton" href="index.php">Regresar</a>
</main>
</body>
</html>
