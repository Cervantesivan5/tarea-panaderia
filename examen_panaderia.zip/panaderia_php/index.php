<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panadería La Espiga</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
<header>
    <h1>Panadería La Espiga</h1>
    <p>Pan fresco todos los días</p>
</header>

<main class="contenedor">
    <h2>Nuestros panes</h2>

    <form action="cuenta.php" method="post">
        <div class="panes">
            <div class="pan">
                <h3>Pan dulce</h3>
                <p>Pan tradicional recién horneado.</p>
                <strong>$12.00</strong>
                <label>Cantidad:
                    <input type="number" name="pan_dulce" min="0" value="0">
                </label>
            </div>

            <div class="pan">
                <h3>Concha</h3>
                <p>Concha suave con cubierta de azúcar.</p>
                <strong>$15.00</strong>
                <label>Cantidad:
                    <input type="number" name="concha" min="0" value="0">
                </label>
            </div>

            <div class="pan">
                <h3>Cuernito</h3>
                <p>Pan hojaldrado y dorado.</p>
                <strong>$18.00</strong>
                <label>Cantidad:
                    <input type="number" name="cuernito" min="0" value="0">
                </label>
            </div>

            <div class="pan">
                <h3>Empanada</h3>
                <p>Empanada rellena y horneada.</p>
                <strong>$20.00</strong>
                <label>Cantidad:
                    <input type="number" name="empanada" min="0" value="0">
                </label>
            </div>

            <div class="pan">
                <h3>Bolillo</h3>
                <p>Bolillo crujiente y recién horneado.</p>
                <strong>$8.00</strong>
                <label>Cantidad:
                    <input type="number" name="bolillo" min="0" value="0">
                </label>
            </div>
        </div>

        <button type="submit">Ver cuenta</button>
    </form>
</main>
</body>
</html>
